package com.github.ixiaow.fragment

import android.app.Activity
import android.content.Context
import android.support.v4.app.Fragment
import android.util.Log

/**
 * 可以确保只有在Activity不为空的情况下执行相关代码
 */
inline fun Fragment.requireActivity(block: Activity.() -> Unit) = activity?.also(block)

/**
 * 可以确保只有在Activity不为空的情况下执行相关代码
 */
inline fun Fragment.requireContext(block: Context.() -> Unit) = context?.also(block)

/**
 * 当前页面是否可见
 */
val Fragment.visible: Boolean
    get() = !isHidden && userVisibleHint

