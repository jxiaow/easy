# android-exts [![](https://jitpack.io/v/ixiaow/android-exts.svg)](https://jitpack.io/#ixiaow/android-exts)

此库主要是收集工作中用到的扩展方法。使用此库可以大大节约开发时间，文档和说明目前正在完善中...

目前已经包含有：

| 包含的模块 | 说明                       |
| ---------- | -------------------------- |
| 协程扩展  | [coroutine](https://github.com/ixiaow/android-exts/tree/master/coroutine/README.md) |
| Fragment扩展   | [fragment](https://github.com/ixiaow/android-exts/tree/master/fragment/README.md) |
| View 扩展  | [View](https://github.com/ixiaow/android-exts/tree/master/view/README.md) |
| exts 其它  | [exts](https://github.com/ixiaow/android-exts/tree/master/exts/README.md) |

## 用法

### Step 1

在根`build.gradle`中添加：

```groovy
allprojects {
    repositories {
        maven { url "https://jitpack.io" }
    }
}
```

在使用的模块`build.gradle`中添加：

```groovy
dependencies {
    // 协程扩展
    implementation 'com.github.ixiaow.android-exts:coroutine:x.y.z'
    // fragment扩展
    implementation 'com.github.ixiaow.android-exts:fragment:x.y.z'
    // view扩展
    implementation 'com.github.ixiaow.android-exts:view:x.y.z'
    // 状态栏管理类
    implementation 'com.gyf.immersionbar:immersionbar:2.3.2-beta01'
}
```
(请替换 x. y .z 为最新的版本号: ![](https://jitpack.io/v/ixiaow/android-exts.svg) )


## 如果您觉得还可以欢迎[Star](https://github.com/ixiaow/android-exts) ,谢谢！


