package com.github.ixiaow.androidktx

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.github.ixiaow.coroutine.ICoroutineScope
import com.github.ixiaow.coroutine.viewScope
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), ICoroutineScope {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewScope.launch {
            Log.d("TAG", "$this, Thread: ${Thread.currentThread().name}")
        }
        mSkip.setOnClickListener {
            val intent = Intent(this@MainActivity, SecondActivity::class.java)
            startActivity(intent)
        }


    }
}

