package com.github.ixiaow.androidktx

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.github.ixiaow.coroutine.ICoroutineScope
import com.github.ixiaow.coroutine.viewScope
import com.github.ixiaow.coroutine.withUI
import com.github.ixiaow.coroutine.withWork
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SecondActivity : AppCompatActivity(), ICoroutineScope {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        viewScope.launch {
            Log.d("TAG", "$this, Thread: ${Thread.currentThread().name}")
            withWork {
                Log.d("TAG", "$this, Thread: ${Thread.currentThread().name}")
                while (isActive) {
                    delay(3000)
                    Log.d("TAG", "$this, Thread: ${Thread.currentThread().name}")
                    withUI {
                        Log.d("TAG", "$this is SecondActivity, Thread: ${Thread.currentThread().name}")
                    }
                }
            }
        }
        "abc".let {
            viewScope.launch {

            }
        }
    }

    override fun onBackPressed() {
        finish()
    }
}
